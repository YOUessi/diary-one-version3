# 已跑的算法自测

1. 手机算法：在mobile目录运行 npm install && npm run typecheck。已在原Mac依赖环境下验证 TypeScript tsc --noEmit 通过。
2. 云端：在cloud目录安装 requirements-test.txt，运行 python3 tests/smoke.py。程序在临时目录生成2张合成JPEG、构造有效Bundle、拦截一次假的Qwen HTTPS响应、验证图片原始字节与模型图片索引、转换为真实Frame ID；不使用外部API。
3. 不包含原始用户视频、照片、API密钥，也不包含未授权MobileCLIP权重。
4. iOS/AVFoundation真机解码与Motion导出、真实模型跨场景语义评测，还需在集成方的环境执行。
5. 本包的“max10”是硬约束和Prompt提示，不证明已经解决原来的语义污染；不允许后端拿结构通过率等同视觉质量。
