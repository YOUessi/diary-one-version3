#!/usr/bin/env python3
"""Offline self-test: synthetic JPEGs -> Bundle V04 -> one fake Qwen request -> Chapter.
Requires Pillow (test only) and jsonschema; no network, user data or API key.
"""
import base64,hashlib,json,sys,tempfile,uuid
from pathlib import Path
from PIL import Image
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from diary_one_ci.bundle import load_app_library_bundle
from diary_one_ci.direct_vlm import run_direct_vlm,MAX_GALLERY
from diary_one_ci.gateway import QwenChatCompletionsAdapter,QwenStageGateway
def fake_bundle(root):
    (root/"frames").mkdir()
    assets=[]
    for i in range(2):
        image=root/"frames"/f"f{i}.jpg"
        Image.new("RGB",(768,1024),(55+i*90,120,180)).save(image,"JPEG",quality=80)
        data=image.read_bytes();digest=hashlib.sha256(data).hexdigest()
        f={"frame_id":f"f{i}","window_index":0,"window_count":1,"sample_role":"PHOTO_REPRESENTATIVE",
           "canonical_offset_ms":4500,"source_timestamp_ms":None,"relative_path":f"frames/f{i}.jpg",
           "sha256":digest,"width":768,"height":1024,"spatial_transform":"ASPECT_FIT_LETTERBOX"}
        assets.append({"asset_id":f"asset-{i}","source_display_name":f"photo{i}.jpg",
           "media_kind":"PHOTO","media_source":"PHONE_LIBRARY_DAY_TEST",
           "original_file_extension":"jpg","original_sha256":digest,"original_bytes":len(data),
           "original_width":768,"original_height":1024,"original_duration_ms":None,
           "original_included":False,"sequence_index":i,"logical_asset_duration_ms":9000,
           "materialized_video":False,"evidence_sampling_profile":"PHOTO_SINGLE_FRAME",
           "evidence_window_count":1,"frames":[f]})
    data={"bundle_version":"DIARY_ONE_APP_LIBRARY_BUNDLE_V04","research_only":True,
          "session":{"session_id":str(uuid.uuid4()),"exported_at":"2026-11-12T00:00:00+00:00",
                     "timezone":"Asia/Tokyo"},
          "device":{"device_id":"offline","hardware_revision":"offline",
                    "firmware_version":"offline","sdk_version":"offline"},
          "normalization":{"width":768,"height":1024,"orientation":"PORTRAIT","aspect_ratio":"3:4",
                           "spatial_transform":"ASPECT_FIT_LETTERBOX",
                           "temporal_transform":"PHONE_TEST_DURATION_WINDOWS_V01",
                           "canonical_frame_offsets_ms":[1500,4500,7500],
                           "evidence_profile_version":"PHONE_TEST_DURATION_WINDOWS_V01"},
          "assets":assets}
    path=root/"bundle.json";path.write_text(json.dumps(data,ensure_ascii=False))
    load_app_library_bundle(path)
    return path
def run():
    with tempfile.TemporaryDirectory() as tmp:
        root=Path(tmp);bundle=fake_bundle(root);seen=[]
        response={"chapters":[{"title":"海港漫步","story":"沿着海滨步行，经过水边建筑和步道，继续欣赏港口的城市景观。",
             "selected_images":[1,2],
             "key_moments":[{"text":"步道与海滨建筑","image_index":2}]}],
             "excluded_images":[]}
        def fake(url,headers,body,timeout):
            obj=json.loads(body);seen.append(obj)
            assert obj["model"]=="qwen3.8-flash" and obj["response_format"]=={"type":"json_object"}
            assert obj["enable_thinking"] is False
            parts=obj["messages"][0]["content"];assert len(parts)==5
            for i,pos in enumerate((2,4)):
                assert f"IMAGE_INDEX_1_BASED={i+1}" in parts[pos-1]["text"]
                b=base64.b64decode(parts[pos]["image_url"]["url"].split(",",1)[1])
                assert b==(root/"frames"/f"f{i}.jpg").read_bytes()
            resp={"id":"offline-req-1","choices":[{"message":{"content":json.dumps(response,ensure_ascii=False)},
                 "finish_reason":"stop"}],"usage":{"prompt_tokens":100,"completion_tokens":80}}
            return 200,{"x-request-id":"offline-req-1"},json.dumps(resp).encode()
        gateway=QwenStageGateway(QwenChatCompletionsAdapter(
            api_key="offline-only",model="qwen3.8-flash",transport=fake))
        out=run_direct_vlm(bundle,gateway)
        assert len(seen)==1 and out["trace"]["model_calls"]==1
        assert out["chapters"][0]["story"]==response["chapters"][0]["story"]
        assert [m["representative_frame_id"] for m in out["chapters"][0]["selected_media"]]==["f0","f1"]
        assert out["chapters"][0]["selected_media"][0]["role"]=="HERO"
        assert MAX_GALLERY==10
        print("PASS: synthetic JPEG -> one fake Qwen request -> original frame IDs -> Chapter; 10 max")
if __name__=="__main__":run()
