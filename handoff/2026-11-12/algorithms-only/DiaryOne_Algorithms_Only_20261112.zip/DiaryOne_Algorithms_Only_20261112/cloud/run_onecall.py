#!/usr/bin/env python3
"""Algorithm-only backend entry point; not an HTTP server.

Usage:
 DASHSCOPE_API_KEY=... python run_onecall.py /private/day/bundle.json --output /private/diary_result.json

The input bundle MUST contain genuine phone-selected JPEG files and checksums.
One global multimodal call; exactly one further whole-day retry only if model
output fails validation. No Planner/Gallery microservice and no BFF dependency.
"""
from __future__ import annotations
import argparse,json,os
from pathlib import Path
from diary_one_ci.direct_vlm import run_direct_vlm
from diary_one_ci.gateway import QwenChatCompletionsAdapter,QwenStageGateway,X02ExecutionError

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("manifest",type=Path)
    ap.add_argument("--output",type=Path,required=True)
    ap.add_argument("--audit-dir",type=Path,default=None)
    ap.add_argument("--model",default=None)
    args=ap.parse_args()
    if not args.manifest.is_file():
        ap.error("source bundle manifest does not exist")
    if args.output.exists():
        ap.error("refusing to overwrite existing output")
    gateway=QwenStageGateway(QwenChatCompletionsAdapter(model=args.model,timeout_seconds=900))
    try:
        result=run_direct_vlm(args.manifest,gateway,audit_dir=args.audit_dir)
    except X02ExecutionError as e:
        print(json.dumps({"state":"REJECTED","code":e.code,
            "stage":e.stage,"model_calls":len(e.stage_runs),
            "request_ids":[x.request_id for x in e.stage_runs]},ensure_ascii=False))
        raise SystemExit(2)
    args.output.parent.mkdir(mode=0o700,parents=True,exist_ok=True)
    fd=os.open(args.output,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
    with os.fdopen(fd,"w",encoding="utf-8") as f:json.dump(result,f,ensure_ascii=False,indent=2)
    print(json.dumps({"state":"COMPLETED","chapters":len(result["chapters"]),
        "total_gallery_images":sum(len(c["selected_media"]) for c in result["chapters"]),
        "model_calls":result["trace"]["model_calls"],
        "result_schema":result["schema_version"],
        "request_ids":result["trace"]["request_ids"]},ensure_ascii=False))
if __name__=="__main__": main()
