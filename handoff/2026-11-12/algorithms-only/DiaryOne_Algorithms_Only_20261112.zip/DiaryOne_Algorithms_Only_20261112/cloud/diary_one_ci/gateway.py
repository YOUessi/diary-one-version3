"""Minimal ONE-CALL Qwen gateway used by direct_vlm.py.

Extracted protocol from historical x02 QwenStageGateway without bundling the
entire 6,899-line multi-stage X02 server. Provider call: one JSON object and all
phone-selected JPEGs. No BFF, database, web API or media uploads to our server.

Requires DASHSCOPE_API_KEY on BACKEND only. No image or API key is logged.
Fake transport can be injected for offline integration tests.
"""
from __future__ import annotations
import base64
import json
import os
import time
import urllib.error
import urllib.request
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Dict, Mapping, Optional, Sequence, Tuple

class X02Error(RuntimeError):
    pass

class X02ModelNotReady(X02Error):
    pass

class X02StageCallError(X02Error):
    def __init__(self, message: str, *, stage_run: "StageRun", code: str):
        super().__init__(message)
        self.stage_run = stage_run
        self.code = code

class X02ExecutionError(X02Error):
    def __init__(self, message: str, *, stage: str, code: str, stage_runs: Sequence["StageRun"]):
        super().__init__(message)
        self.stage = stage
        self.code = code
        self.stage_runs = tuple(stage_runs)

@dataclass(frozen=True)
class StageRun:
    stage: str
    output: Dict[str, object]
    provider: str
    model: str
    request_id: str
    input_tokens: int
    output_tokens: int
    latency_seconds: float
    model_frame_count: int
    model_calls: int
    pricing_currency: str
    input_rate_per_million: float
    output_rate_per_million: float
    native_currency_per_usd: float
    pricing_basis: str
    selected_evidence: Tuple[Dict[str, object], ...] = ()
    call_status: str = "COMPLETED"
    transport_diagnostics: Dict[str, object] = field(default_factory=dict)
    checkpoint_provenance: Dict[str, object] = field(default_factory=dict)
    finish_reason: Optional[str] = None

    @property
    def estimated_cost_native(self) -> float:
        return (self.input_tokens * self.input_rate_per_million +
                self.output_tokens * self.output_rate_per_million) / 1_000_000

    @property
    def estimated_cost_usd(self) -> float:
        return self.estimated_cost_native / self.native_currency_per_usd

Transport = Callable[[str, Mapping[str, str], bytes, float], Tuple[int, Mapping[str, str], bytes]]

def _transport(url: str, headers: Mapping[str, str], body: bytes, timeout: float):
    request = urllib.request.Request(url, data=body, headers=dict(headers), method="POST")
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return response.status, dict(response.headers.items()), response.read()
    except urllib.error.HTTPError as error:
        return error.code, dict(error.headers.items()), error.read()

def _json_text(payload: Mapping[str, object]) -> str:
    choices = payload.get("choices")
    if not isinstance(choices, list) or not choices or not isinstance(choices[0], dict):
        raise ValueError("Missing choices")
    message = choices[0].get("message")
    if not isinstance(message, dict):
        raise ValueError("Missing assistant message")
    content = message.get("content")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = [x.get("text") for x in content if isinstance(x, dict) and isinstance(x.get("text"), str)]
        if parts:
            return "\n".join(parts)
    raise ValueError("No model text")

class QwenChatCompletionsAdapter:
    provider = "alibaba_model_studio"
    credential_environment = "DASHSCOPE_API_KEY"
    pricing_currency = "CNY"

    def __init__(self, *, api_key: Optional[str] = None, model: Optional[str] = None,
                 base_url: Optional[str] = None, timeout_seconds: float = 180.0,
                 transport: Optional[Transport] = None):
        self.api_key = api_key if api_key is not None else os.environ.get("DASHSCOPE_API_KEY", "")
        self.model = model or os.environ.get("DIARY_ONE_DIRECT_VLM_MODEL", "qwen3.8-flash")
        self.base_url = (base_url or os.environ.get("DIARY_ONE_X01_QWEN_BASE_URL")
                         or "https://dashscope.aliyuncs.com/compatible-mode/v1").rstrip("/")
        if not self.base_url.startswith("https://"):
            raise ValueError("Qwen base_url must be HTTPS")
        self.timeout_seconds = timeout_seconds
        self.transport = transport or _transport
        # qwen3.8-flash actual tier must be configured by integrating backend;
        # unconfigured rates stay 0 and are NOT presented as zero real cost.
        self.input_rate_per_million = float(os.environ.get("DIARY_ONE_X01_QWEN_INPUT_CNY_PER_MTOK", "0"))
        self.output_rate_per_million = float(os.environ.get("DIARY_ONE_X01_QWEN_OUTPUT_CNY_PER_MTOK", "0"))
        self.native_currency_per_usd = float(os.environ.get("DIARY_ONE_X01_CNY_PER_USD", "7.20"))
        if self.native_currency_per_usd <= 0:
            raise ValueError("DIARY_ONE_X01_CNY_PER_USD must be >0")
        if min(self.input_rate_per_million, self.output_rate_per_million) < 0:
            raise ValueError("Token rates cannot be negative")
        self.pricing_basis = os.environ.get("DIARY_ONE_X01_QWEN_PRICING_BASIS", "configured-or-unconfigured")

    @property
    def ready(self) -> bool:
        return bool(self.api_key.strip())

    def request_options(self) -> dict:
        # Match the original Direct VLM default; do not silently alter sampling.
        return {"enable_thinking": False}

class StageModelGateway:
    provider = "abstract"
    model = "abstract"

    @property
    def ready(self):
        return False

    def call(self, stage, prompt, schema, evidence=(), context=None):
        raise NotImplementedError


class QwenStageGateway(StageModelGateway):
    def __init__(self, adapter: QwenChatCompletionsAdapter):
        self.adapter = adapter
        self.provider = adapter.provider
        self.model = adapter.model
        self.credential_environment = adapter.credential_environment

    @property
    def ready(self) -> bool:
        return self.adapter.ready

    def _make_run(self, stage, output, request_id, usage, latency, frame_count,
                  *, finish_reason=None, status="COMPLETED"):
        return StageRun(stage=stage, output=output, provider=self.provider, model=self.model,
            request_id=request_id, input_tokens=int(usage.get("prompt_tokens", usage.get("input_tokens", 0))),
            output_tokens=int(usage.get("completion_tokens", usage.get("output_tokens", 0))),
            latency_seconds=latency, model_frame_count=frame_count, model_calls=1,
            pricing_currency=self.adapter.pricing_currency,
            input_rate_per_million=self.adapter.input_rate_per_million,
            output_rate_per_million=self.adapter.output_rate_per_million,
            native_currency_per_usd=self.adapter.native_currency_per_usd,
            pricing_basis=self.adapter.pricing_basis, finish_reason=finish_reason,call_status=status)

    def call(self, stage: str, prompt: str, schema: Mapping[str, object],
             evidence: Sequence[Tuple[Mapping[str, object], Mapping[str, object], Path]] = (),
             context: Optional[Mapping[str, object]] = None) -> StageRun:
        if not self.ready:
            raise X02ModelNotReady("DASHSCOPE_API_KEY required on backend")
        context = context or {}
        full_prompt = (prompt + "\nReturn exactly one valid JSON object. Do not include markdown. "
                       "The object must conform to this schema:\n" +
                       json.dumps(schema, ensure_ascii=False))
        content = [{"type":"text","text":full_prompt}]
        chronological = context.get("_direct_vlm_frame_chronology")
        for index,(asset,frame,path) in enumerate(evidence,1):
            if stage == "DIRECT_VLM_GLOBAL_EDITOR":
                if not isinstance(chronological, dict):
                    raise X02Error("Missing full-day frame chronology map")
                label = chronological.get(str(frame["frame_id"]))
                if not isinstance(label,str) or not label.startswith("IMAGE_INDEX_1_BASED="):
                    raise X02Error(f"Missing compact IMAGE_INDEX chronology for frame {index}")
            else:
                label = f"IMAGE_INDEX_1_BASED={index} FRAME_ID={frame['frame_id']}"
            content.append({"type":"text","text":label})
            data = Path(path).read_bytes()
            content.append({"type":"image_url",
                            "image_url":{"url":"data:image/jpeg;base64,"+base64.b64encode(data).decode("ascii")}})
        body={"model":self.model,
              "messages":[{"role":"user","content":content}],
              "response_format":{"type":"json_object"},
              **self.adapter.request_options(),"stream":False}
        headers={"Authorization":"Bearer "+self.adapter.api_key,
                 "Content-Type":"application/json","Accept":"application/json"}
        started=time.monotonic()
        try:
            status,resp_headers,response=self.adapter.transport(
                self.adapter.base_url+"/chat/completions",headers,
                json.dumps(body,ensure_ascii=False,separators=(",",":")).encode(),self.adapter.timeout_seconds)
        except Exception as error:
            failure=self._make_run(stage,{},"transport-no-response",{},time.monotonic()-started,
                                   len(evidence),status="FAILED_BEFORE_RESPONSE")
            raise X02StageCallError("Qwen transport failed",stage_run=failure,
                                    code="MODEL_TRANSPORT_FAILED") from error
        latency=time.monotonic()-started
        lower={str(k).lower():v for k,v in dict(resp_headers).items()}
        response_id=str(lower.get("x-request-id") or lower.get("x-dashscope-request-id")
                        or "qwen-request-unknown")
        if not 200<=status<300:
            failure=self._make_run(stage,{},response_id,{},latency,len(evidence),status="HTTP_FAILED")
            raise X02StageCallError(f"Model HTTP {status}",stage_run=failure,code=f"MODEL_HTTP_{status}")
        payload={}
        try:
            payload=json.loads(response.decode("utf-8"))
            if not isinstance(payload,dict):raise ValueError("Model response is not an object")
            usage=payload.get("usage",{})
            usage=usage if isinstance(usage,dict) else {}
            response_id=str(lower.get("x-request-id") or lower.get("x-dashscope-request-id")
                            or payload.get("request_id") or payload.get("id") or "qwen-request-unknown")
            output=json.loads(_json_text(payload))
            if not isinstance(output,dict):raise ValueError("Model output is not object")
        except (UnicodeDecodeError, ValueError, TypeError, KeyError) as error:
            usage=payload.get("usage",{}) if isinstance(payload,dict) else {}
            usage=usage if isinstance(usage,dict) else {}
            failure=self._make_run(stage,{},response_id,usage,latency,len(evidence),status="RESPONSE_INVALID")
            raise X02StageCallError("Model returned invalid JSON",stage_run=failure,
                                    code="MODEL_STRUCTURED_OUTPUT_INVALID") from error
        choices=payload.get("choices",[])
        finish=(choices[0].get("finish_reason") if isinstance(choices,list) and
                choices and isinstance(choices[0],dict) else None)
        return self._make_run(stage,output,response_id,usage,latency,len(evidence),finish_reason=finish)



def _app_asset_uuid(asset_id: str) -> str:
    # Preserve the original X02 identity mapping for App/BFF contracts.
    value = asset_id[6:] if asset_id.startswith("asset_") else asset_id
    try:
        return str(uuid.UUID(value))
    except ValueError:
        return value


def _manifest_frame_path(bundle, frame: Mapping[str, object]) -> Path:
    parent = Path(bundle.manifest_path).parent.resolve()
    raw = Path(str(frame["relative_path"]))
    if raw.is_absolute() or ".." in raw.parts:
        raise X02Error("Frame path is not confined to the source bundle")
    path = (parent / raw).resolve()
    if not path.is_relative_to(parent):
        raise X02Error("Frame path escapes the bundle directory")
    return path
