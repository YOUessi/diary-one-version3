# 最小算法接入接口

## 1. 手机上抽帧及打包

入口：mobile/src/index.ts。

~~~ts
import { buildAppLibraryBundle } from './src/index';
// chosenMedia 由已有App的授权媒体列表提供；SDK不负责页面与账号。
const { bundle, jsonPath, sourceUris } =
  await buildAppLibraryBundle(chosenMedia, bundleDir, 'V05');
~~~

buildAppLibraryBundle 会调用 MobileCLIP FP16/V05/V07 处理原始视频并得到代表JPEG。bundle里每一帧包含 frame_id、source_timestamp_ms、relative_path、sha256 等。请上传 manifest 和选中JPEG，不要把用户原始10秒MP4传给多模态模型。原片应在手机留存，以便最后生成Motion。

需要原生 iOS Expo Dev Client/TestFlight + ONNX模型文件；Expo Go无法运行 Swift/ONNX模块。Android等价原生模块需要额外实现和验证。

## 2. 云端一次VLM

Python>=3.11，依赖 cloud/requirements.txt，API密钥只存在于后端。

~~~python
from pathlib import Path
from diary_one_ci.direct_vlm import run_direct_vlm
from diary_one_ci.gateway import QwenChatCompletionsAdapter, QwenStageGateway
result = run_direct_vlm(
    Path('/private/day/bundle.json'),
    QwenStageGateway(QwenChatCompletionsAdapter(model='qwen3.8-flash')),
    audit_dir=Path('/private/day/private_audit'),
)
~~~

等价CLI：在cloud目录运行 python3 run_onecall.py --help。

Qwen获得全部端侧抽帧，图片前附真实IMAGE_INDEX_1_BASED与CLIP_SEQUENCE_1_BASED标签，只生成一个JSON对象，类似：

~~~json
{
  "chapters": [{
    "title": "海港漫步",
    "story": "自然叙述完整经历",
    "selected_images": [2, 7, 10],
    "key_moments": [{"text": "海滨远景", "image_index": 7}]
  }],
  "excluded_images": []
}
~~~

最终发布结果的 Schema 位于 cloud/contracts/direct_vlm_chapter_v01.schema.json。模型的图库第一个 selected_images 为Hero，必须确定性映射到真实Frame ID及source_asset_id。单章最多10张，不能自动截断；即使索引和时间合法也需另行检查图像语义是否属于Chapter。

默认非思考模式，temperature和seed未被额外设定。真实费用单价从后端环境变量 DIARY_ONE_X01_QWEN_INPUT_CNY_PER_MTOK / OUTPUT_CNY_PER_MTOK 配置；未设置时估算结果为0不代表免费。最多250张JPEG和35MiB原始图字节，超限应拒绝。

## 3. 选中帧映射成本地3秒Motion

把服务端结果的 chapters 与真实bundle、sourceUris一起传给：

~~~ts
import { attachOneCallLiveMotion } from './src/index';
const localChapters = await attachOneCallLiveMotion(
  serverResult.chapters,
  bundle, bundleDir, sourceUris, '2026-11-12'
);
~~~

适配器检查 Hero、源 Asset、Frame ID、真实PTS及图库<=10，再在V05下调用 buildLiveChapterCovers。本地Swift从原视频导出 3秒静音MOV+封面JPG；最多优先物化3个Motion，其余使用原始视频3秒窗口。V04只保留静态图。系统原生Live Photo配对尚未实现。

## 4. 为什么没有BFF

用户的后端开发者已有账号、鉴权、上传、队列、数据库与存储能力。本SDK只提供算法源码、接口格式和结果身份映射，不提供新的服务端Web框架或业务实现。
