/** Algorithm-only Chapter and 3-second Motion types.
 * Extracted from the app model; excludes UI demo/seed chapters and preferences.
 */
export type MemoryOrder = { capturedAtMs?: number; sourceSequenceIndex?: number };

export type ChapterMotionCover = {
  kind: 'chapter_motion';
  status: 'rendered' | 'source_window';
  posterUri: string;
  motionUri: string;
  sourceVideoUri: string;
  focusTimeSec: number;
  clipStartSec: number;
  clipEndSec: number;
  applePhotosPaired: false;
};

export type MemoryMedia = {
  id: string;
  label: string;
  capturedByYou?: boolean;
  posterUri?: string;
  playbackUri?: string;
  focusTimeSec?: number;
  sourceAssetId?: string;
  selectedFrameId?: string;
  sourceDurationSec?: number;
  motionCover?: ChapterMotionCover;
};

export type Chapter = MemoryOrder & {
  id: string;
  title: string;
  dateKey: string;
  dateLabel: string;
  weakTime?: string;
  aiStory: string;
  previewStory?: string;
  tags: string[];
  heroUri?: string;
  motionCover?: ChapterMotionCover;
  moments: MemoryMedia[];
  highlights?: {id: string; text: string; media?: MemoryMedia[]}[];
};

export type CapturedOriginal = {
  id: string;
  intakeSource?: 'DEVICE_MANUAL' | import('./domain/mediaIntake').MediaIntakeSource;
  dateKey: string;
  kind: 'photo' | 'video';
  durationSec?: number;
  posterUri?: string;
  playbackUri?: string;
  capturedAtLabel?: string;
};
