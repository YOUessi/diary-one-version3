# 后端接口与结果格式

## 手机至生产BFF

生产端点：POST /v1/day-revisions，使用认证multipart表单，至少包含manifest、稳定的day_revision_id和对应JPEG附件。字段、附件文件名及profile策略以source/apps/mobile/src/cloud/researchClient.ts中的buildBundleMultipartForm及backend/productionCloudService.ts为事实源，不要凭文字自行猜测文件字段。

请求成功返回job_id。手机通过GET /v1/jobs/{job_id}轮询状态，完成后取得受合同约束的整日结果。同一day_revision_id发生重试时必须保持幂等；账户、媒体SHA、来源路径、原始帧信息不可变化。

研究预览入口：/x02/v0.4.1/preview。正式用户App走BFF，不使用研究服务直连。

## 手机Bundle

Bundle V04/V05。每个asset：asset_id、sequence_index、media_kind、original_duration_ms等；每帧：frame_id、relative_path、source_timestamp_ms（原始片内PTS）、sha256、width、height、sample_role等。

不要将video source_timestamp_ms错误理解为整天绝对时间。模型看到的IMAGE_INDEX与CLIP_SEQUENCE是两个不同编号空间；代码必须映射原始frame_id，不允许凭拍摄时间或全局索引重新猜。

## 一次云端多模态API

单次Qwen3.8-Flash看所有真实JPEG（不是每图一次调用、不是两个阶段）。返回一个JSON对象，核心样例：

    chapters:
      - title: 环形码头与歌剧院
        story: 自然完整的简体中文经历回顾
        selected_images: [1, 7, 10]
        key_moments:
          - text: 重要瞬间
            image_index: 7
    excluded_images: []

selected_images内第一个IMAGE_INDEX即封面，最多10张，一般3–8张；不得把截图中不是当前经历的内容混进本章。模型不得凭空猜作品标题、地点或用户行为。模型生成结果在程序校验之前都应视为不可信输入。

## 返回手机

Schema：DIARY_ONE_DIRECT_VLM_CHAPTER_V01，实际完整结构在source/services/bff/shared/contracts/direct_vlm_chapter_v01.schema.json。
包含：
- trace.pipeline_version = X02_DIRECT_VLM_CHAPTER_V01。
- editor_policy = DIRECT_VLM_GLOBAL_EDITOR_V01。
- chapters[*].title / story / hero_frame_id / hero_asset_id。
- chapters[*].selected_media[]，每项必须绑定 source_asset_id、representative_frame_id、focus_pts_ms和source_video时间元数据。
- chapters[*].key_moments、experience_frame_ids、decision_trace、trace.request_ids。
- bundle_manifest_sha256 / session_id 来源约束。

交接版contract schema已将selected_media最大数量设为10，手机algorithmLock.ts中SHA也已同步。不能让旧20张版服务器与新10张版手机客户端混用。

## Live/Motion

后端只返回Hero和源片段关联。3s JPG+MOV由手机在经过最终结果校验后，从本地原始10s视频生成；对齐关键帧focus_pts_ms，头尾使用3秒区间钳制。输出motionCover.status=rendered时才表示本地MOV存在，失败回退source_window。applePhotosPaired=false，**并非系统相册已配对Live Photo**。

## 服务端建议配置

- DASHSCOPE_API_KEY应只存在于后端安全环境变量。
- 请求Token/费用与Provider Request ID存入私有日志，不携带模型输入JPEG Base64到日志。
- 超限、合同失败、时间归属异常、图库过量都应拒绝；不得切前10张或默默移动到其他Chapter。
- 真实质量验收需另有语义层评测，不能以来源Clip不交叉证明内容属于同一Chapter。
