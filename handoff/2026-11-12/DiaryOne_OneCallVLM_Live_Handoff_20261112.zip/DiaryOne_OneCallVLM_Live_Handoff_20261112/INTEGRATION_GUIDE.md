# 后端开发者接入说明

## 真实处理流程

采集：第一人称10s原视频，常见节奏约每2分钟一段；支持主动拍摄。手机端对每段视频用 iOS AVFoundation 按真实PTS解码候选帧。

端侧：MobileCLIP-S0内部FP16、输出float32，执行端点证据门控V05及coverage V07，从片段中选有信息价值的1–5张JPEG（特殊路径最多10张），归一化为768×1024，并计算SHA256。模型不是云端VLM，端侧权重需要受控分发。

封装：source/apps/mobile/src/pipeline/buildAppLibraryBundle.ts + bundleTypes.ts 构造带片段来源asset_id、frame_id、sequence_index、PTS和JPEG SHA的Bundle V04/V05。手机保留原始MP4和帧图，不要上传原始视频给多模态模型。

上传：source/apps/mobile/src/backend/productionCloudService.ts 和 cloud/researchClient.ts。正式App走BFF生产认证Job，不把研究直连Token用于正式用户。BFF按 manifest 的每一条source path与SHA核验真实JPEG文件和用户身份。

云端：source/services/algorithm/algorithm/src/diary_one_ci/direct_vlm.py 与 direct_vlm_compact.py。把全部选中的JPEG和每张图的IMAGE_INDEX_1_BASED、CLIP_SEQUENCE_1_BASED、真实PTS按时间顺序一次交给Qwen3.8-Flash。模型只生成Chapter完整经历Story、selected_images（第一张Hero）、key_moments、excluded_images。最多允许1次失败重试，全部调用计费并保存Request ID。

绑定：云端把数字图片序号准确映射回输入frame_id，返回DIARY_ONE_DIRECT_VLM_CHAPTER_V01。BFF调用shared/direct_result_contract.py做合同、原图、来源、SHA、鉴权、会话与发布验证。手机validateDirectVlmResult.ts二次绑定校验，mapPreviewResult.ts映射日记。

动态封面：返回最终Chapter后，由手机attachChapterMedia.ts决定是否启用Bundle V05动图；buildLiveChapterCovers.ts从该章选中的本地原片做3秒Motion，Swift ChapterMotionExporter.swift导出JPG+静音MOV，或者不导出时以3秒source_window播放。仅最终入选Chapter生成，默认最多3个高优先级Motion物化，其余按需播放，不修改10s原片。

## 入口文件与运行时

- 端侧核心：apps/mobile/src/evidence/runSemanticVideoEvidence.ts、mobileclip/analyzer.ts、mobileclip/endpointV05.ts、mobileclip/coverageV07.ts、nativeVideoDecoder.ts。
- 端侧Bundle与调度：pipeline/buildAppLibraryBundle.ts、runPipeline.ts、attachChapterMedia.ts、buildLiveChapterCovers.ts。
- iOS原生：apps/mobile/modules/diary-one-vision/ios/DiaryOneVisionModule.swift、VideoFrameTimeline.swift、ChapterMotionExporter.swift、EvidenceFrameNormalizer.swift。
- 生产上传与轮询：apps/mobile/src/backend/productionCloudService.ts；BFF bff/routes/day_revisions.py 和 jobs.py。
- 云端唯一编辑器：services/algorithm/algorithm/src/diary_one_ci/direct_vlm.py、direct_vlm_compact.py、x02.py、x01_server.py。
- 结果合同：services/bff/shared/direct_result_contract.py 与 contracts/direct_vlm_chapter_v01.schema.json，手机src/cloud/validateDirectVlmResult.ts。

## 版本/限制

- Expo SDK 57，React Native 0.86.3，TypeScript约6，onnxruntime-react-native 1.24.3，Python源项目>=3.9。Swift依赖AVFoundation。
- 完整手机构建需要node_modules（npm ci）和授权模型权重；本包不含这些运行时二进制。
- App用V05才执行本地3秒Motion；V04仅使用静态封面。
- 云端最大250帧和35MiB原JPEG，超出要显式失败。
- 用户实际图像、密钥、个人录像均未加入交接包。
- iOS的本地解码/Motion有Swift实现；Android需要独立补齐等价原生模块并测性能，不能直接认为当前iOS行为可移植。
- 现有模型质量问题：即使图像索引、时间、JSON合法，仍可能选错章节；后端必须额外验收具体作品、封面、重复、语义归属和关键场景召回。不要把机器结构通过率当视觉质量评分。
