# 运行与验收

1. 无网络基础检查：python3 tests/handoff_smoke.py。
2. Python源文件语法检查：python3 -m compileall -q source/services/algorithm/algorithm/src/diary_one_ci source/services/bff。
3. 完整手机工程依赖：在source/apps/mobile执行npm ci，再执行npm run typecheck；模型权重另行由团队提供并校验manifest SHA。
4. 端侧真实抽帧和3秒Motion必须在iOS原生Dev Client/TestFlight运行；Expo Go不含本地Swift和ONNX Runtime模块。
5. 真实Qwen测试需要后端密钥，且应记录每次Token、请求ID、花费、结果原始JSON与语义评审。
6. 老测试中若仍按V04 20张合同编写断言，不应假称通过最新max10合同；交接版另有独立smoke用于验收新约束。

## 真实状态

本包是基于当前Mac工作树的**源码交付、非正式生产发布**。原始V04允许20张；交接版修改为10张并移除静默截断与round-robin删图。未宣称修改后的Prompt已经在所有素材上达到稳定语义质量。手机版本仍有受控模型权重缺失这一明确的安装前置条件。

iOS“Live图”实际是App内3秒静音MOV/JPG，不是Apple Photos原生HEIC/MOV配对Live Photo。若后端希望生成真正系统Live Photo，需要另起独立开发验收任务，不要在接口中谎称已经支持。
