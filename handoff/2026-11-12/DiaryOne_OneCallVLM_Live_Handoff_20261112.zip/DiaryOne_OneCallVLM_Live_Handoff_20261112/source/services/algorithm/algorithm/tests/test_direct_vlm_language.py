"""Chinese language gate and text-only rewrite without full-image re-planning."""
import copy
import json
import os
import uuid
from pathlib import Path
from types import SimpleNamespace

import pytest
from diary_one_ci import direct_vlm, direct_vlm_language as language
from diary_one_ci.x02 import StageRun, X02ExecutionError


def raw_english():
    return {
        "chapters": [{
            "title": "The Rocks District",
            "story": "Visitors walk through historic sandstone alleys and lively markets near the harbour.",
            "selected_images": [1, 2],
            "key_moments": [{"text": "An outdoor market stall", "image_index": 2}],
        }],
        "excluded_images": [],
    }


def source_fixture(tmp_path):
    assets = []
    evidence = []
    owners = {}
    for i in range(2):
        aid = f"asset_{i}"
        fid = f"frame_{i}"
        asset = {"asset_id": aid, "sequence_index": i, "media_kind": "VIDEO",
                 "original_duration_ms": 10000}
        frame = {"frame_id": fid, "canonical_offset_ms": 4500, "source_timestamp_ms": 4500}
        path = tmp_path / (fid + ".jpg")
        path.write_bytes(b"fixture-jpeg")
        evidence.append((asset, frame, path))
        owners[fid] = {"asset": asset, "frame": frame, "path": path, "sequence": i + 1}
        assets.append(asset)
    source = tmp_path / "bundle.json"
    manifest = {"session": {"session_id": str(uuid.uuid4())}, "assets": assets}
    source.write_text(json.dumps(manifest))
    return source, SimpleNamespace(manifest=manifest,manifest_path=source), evidence, owners


def translated_texts():
    return {
        "texts": [
            "岩石区（The Rocks）历史街区",
            "沿着海港旁的历史砂岩小巷行走，可以看到热闹的露天市集。",
            "露天市集的一个摊位",
        ],
    }


def test_english_paragraphs_fail_but_chinese_with_english_landmark_passes():
    bad = raw_english()
    issues = language.chinese_text_errors(bad)
    assert len(issues) == 3
    good,errs = language.apply_text_only_repair(bad,translated_texts())
    assert not errs and good
    assert not language.chinese_text_errors(good)
    assert good["chapters"][0]["title"].startswith("岩石区")
    assert good["chapters"][0]["selected_images"] == [1,2]


def test_text_only_rewrite_preserves_every_nontext_field():
    source = raw_english()
    output, errors = language.apply_text_only_repair(source, translated_texts())
    assert not errors and output is not None
    assert output["excluded_images"] == source["excluded_images"]
    assert output["chapters"][0]["selected_images"] == source["chapters"][0]["selected_images"]
    assert output["chapters"][0]["key_moments"][0]["image_index"] == 2
    assert source["chapters"][0]["title"] == "The Rocks District"


@pytest.mark.parametrize("answer,expected", [
    ({"texts": ["岩石区（The Rocks）"]}, "text_field_count_mismatch"),
    ({"texts": ["岩石区", "", "露天市集"]}, "empty_or_nonstr_text"),
    ({"texts": ["The Rocks", "English paragraph", "English caption"]}, "language:"),
    ([], "output_not_object"),
])
def test_repair_is_fail_closed(answer, expected):
    output,errors=language.apply_text_only_repair(raw_english(),answer)
    assert output is None and any(expected in x for x in errors),errors


def test_stage_repair_uses_zero_images_and_accounts_for_cost(monkeypatch,tmp_path):
    source,bundle,evidence,owners = source_fixture(tmp_path)
    monkeypatch.setattr(direct_vlm,"prepare_evidence",lambda _:(bundle,evidence,owners,50))
    seen=[]
    class ScriptedGateway:
        ready=True
        provider="fixture"
        model="qwen3.8-flash"
        def call(self,stage,prompt,schema,evidence,context):
            seen.append((stage,len(evidence),prompt))
            response = raw_english() if stage == direct_vlm.STAGE else translated_texts()
            return StageRun(stage=stage,output=response,provider="fixture",model="qwen3.8-flash",
                request_id="test-request-"+str(len(seen)),input_tokens=200 if evidence else 30,
                output_tokens=40 if evidence else 20,latency_seconds=.1,model_frame_count=len(evidence),
                model_calls=1,pricing_currency="CNY",input_rate_per_million=.8,
                output_rate_per_million=2.7,native_currency_per_usd=7.2,pricing_basis="fixture")
    result=direct_vlm.run_direct_vlm(source,ScriptedGateway(),audit_dir=tmp_path/"audit")
    assert [x[:2] for x in seen]==[(direct_vlm.STAGE,2),("DIRECT_VLM_LANGUAGE_REPAIR",0)]
    assert result["trace"]["model_calls"]==2
    assert result["trace"]["input_tokens"]==230
    assert result["decision_trace"]["text_only_language_repair"] is True
    assert result["decision_trace"]["chapter_language_validated"] is True
    assert result["chapters"][0]["title"] == "岩石区（The Rocks）历史街区"
    assert result["chapters"][0]["hero_frame_id"] == "frame_0"
    assert len(list((tmp_path/"audit").glob("attempt_*.json")))==2


def test_invalid_text_repair_does_not_repeat_images(monkeypatch,tmp_path):
    source,bundle,evidence,owners=source_fixture(tmp_path)
    monkeypatch.setattr(direct_vlm,"prepare_evidence",lambda _:(bundle,evidence,owners,50))
    seen=[]
    class BadLanguageGateway:
        ready=True
        def call(self,stage,prompt,schema,evidence,context):
            seen.append((stage,len(evidence)))
            value=raw_english() if evidence else {"texts":["The Rocks", "Only English", "English"]}
            return StageRun(stage=stage,output=value,provider="fixture",model="model",
                request_id=f"test-{len(seen)}",input_tokens=20,output_tokens=10,
                latency_seconds=.1,model_frame_count=len(evidence),model_calls=1,
                pricing_currency="CNY",input_rate_per_million=.8,output_rate_per_million=2.7,
                native_currency_per_usd=7.2,pricing_basis="fixture")
    with pytest.raises(X02ExecutionError) as err:
        direct_vlm.run_direct_vlm(source,BadLanguageGateway(),audit_dir=tmp_path/"audit")
    assert err.value.code=="DIRECT_VLM_LANGUAGE_INVALID"
    assert seen==[(direct_vlm.STAGE,2),("DIRECT_VLM_LANGUAGE_REPAIR",0)]
    assert len(err.value.stage_runs)==2
