"""Compact Direct VLM editorial protocol and deterministic, evidence-bound converter.

A multimodal model makes only editorial decisions. It receives 1-based image
indices and source-grounded clip chronology. It does not copy UUID Frame IDs,
author giant evidence lists, choose JSON media IDs, or duplicate hero references.

This module makes NO API calls. All conversion is pure and fail-closed.
"""
from __future__ import annotations

import math
from pathlib import Path
from typing import Any, Mapping, Sequence

from jsonschema import Draft202012Validator

MODEL_PROTOCOL = "DIRECT_VLM_COMPACT_EDITOR_V04"
MAX_CHAPTERS = 14
MAX_GALLERY = 10
SCHEMA = {
    "type": "object",
    "required": ["chapters"],
    "properties": {
        "chapters": {
            "type": "array", "minItems": 1, "maxItems": MAX_CHAPTERS,
            "items": {
                "type": "object",
                "required": ["title", "story", "selected_images"],
                "properties": {
                    "title": {"type": "string"},
                    "story": {"type": "string"},
                    "selected_images": {
                        "type": "array", "minItems": 1, "maxItems": MAX_GALLERY,
                        "items": {"type": "integer", "minimum": 1}
                    },
                    "key_moments": {
                        "type": "array", "maxItems": 10,
                        "items": {
                            "type": "object",
                            "required": ["text", "image_index"],
                            "properties": {
                                "text": {"type": "string"},
                                "image_index": {"type": "integer", "minimum": 1}
                            },
                        },
                    },
                },
            }
        },
        "excluded_images": {
            "type": "array", "maxItems": 250,
            "items": {"type": "integer", "minimum": 1}
        },
    },
}
_VALIDATOR = Draft202012Validator(SCHEMA)


def prompt(*, image_count: int, clip_count: int, retry: bool = False) -> str:
    """Single global visual timeline editor. Format does not force chapter count."""
    if image_count <= 0 or clip_count <= 0:
        raise ValueError("Empty direct VLM input")
    basic = f"""你是第一人称生活记录的全局 Chapter 编辑。输入共有 {image_count} 张 JPEG、{clip_count} 个按时间排列的片段。
每张图片紧前方标注 IMAGE_INDEX_1_BASED（1 到 {image_count}）、CLIP_SEQUENCE_1_BASED（1 到 {clip_count}）和可核实的原视频相对时间。原视频相对时间不是时钟时间。
请看完所有图片，理解完整时间线，直接划分最自然的 Chapter，并写故事及选取互补图片。

【内容原则】
1. 优先依据真实时间先后与完整经历分章：通常一个 Chapter 对应一段连续、主题完整的体验，而不是一个小景点、一条街、一张照片。仅当经历的主要地点或活动主题确实改变时才开新章。不要按固定时间机械拆分，也不要为了选更多照片增加 Chapter 数量。
2. 在同一地区连续进行的步行、购物、摊位浏览、短暂演出等互有关联的场景应优先归入同一个经历 Chapter，除非真正发生独立的重要活动变化。即使出现多个可识别地名，也不代表必须每个地名分章；避免同一经历被拆成两个几乎重复的 Chapter。不同时刻重复出现同一地标，不能跨过无关经历强行合并。
3. 不要遗漏市集、海事馆、商业街、历史建筑、教堂、园林、特殊活动等短暂且独特的场景，也不要因为都属于 Citywalk 就归为一个泛泛的章。
4. 仅凭画面可见证据作事实描述：不可凭视频相对时间推断“黄昏”“下午”“周末”、购物完成、主观心情和用户意图。地标身份不确定时保守描述。
5. 忽略前后宣传片、地图介绍、视频水印上的不真实信息。excluded_images 可记录明确不是实际生活内容的图片序号，禁止把它们选入章节图库。

【视觉筛选原则：判断实际图片，而不是套用旅行模板】
- 逐张观察实际可见的主体、活动、环境、构图与辨识度。时间、地点和相邻帧仅用于排序、辅助定位和验证，不能代替看图；不得凭文件名、GPS、路线介绍或视频字幕臆测画面没有出现的内容。
- 先理解完整时间线与连续经历，再决定 Chapter。分章看真实的时间推进、地点与活动变化；同一市场中不同摊位和短暂街头表演未必需要拆章，不同的独立活动也不能仅因相距很近而合并。
- 每章横向比较所有相关图片：优先保留能够建立地点、体现核心活动、解释空间关系、提供独特细节、推进场景或自然收尾的画面。一个章节的图库应覆盖不同信息角色，不要只堆地标，也不要只选好看的空景。
- 画面质量检查：主体是否明确、完整且可辨认；光线、清晰度、构图、遮挡、水印/字幕是否影响理解。重要且稀有的独特画面即使有轻微瑕疵，也可优先于普通重复背景。
- 按视觉内容和信息增量去重，不以时间相近直接删除，也不以时间相远就自动认为不同。相邻画面分别展示全景与独特活动可同时保留；跨时段重复水面、绿地、普通道路或同角度建筑应优先选择更有代表性的一张。
- 第一个 selected_images 是封面：必须来自该章实际入选图片，且能同时代表章内主要内容、地点特征或活动，不要只选清楚但过于局部的次要画面。
- 对同一主题的多张可用图片，按主体清晰度、地点/活动辨识度、信息增量和互补性比较，仅把最有代表性的图片放入 selected_images。没有进入图库的图片依然是有效视觉证据，不等于坏图；普通重复图绝不能标记为 excluded_images。excluded_images 仅用于确实非生活记录、宣传片/路线介绍或无法使用的损坏画面。
- 不按固定时间、每章固定照片数或全日固定比例强行选图。每张入选图必须提供与其他入选图不同的具体信息价值。宁可少选，也不为凑图而选择图片，不为增加图片数而多拆 Chapter。
- 不要预设悉尼或任何其他路线中的地点名称、章节数量、图片数量或故事情节。旅行、骑行、亲子、工作、钓鱼、购物等场景必须根据当前图片实际内容独立判断；这些场景名称不是必选清单。

【可选的 GPS/地点辅助信息】
- 默认可能完全没有 GPS；没有就仅凭图片与可信时间线工作，不得填充虚构坐标或路线。
- 若对应图片旁明确提供 GEO_* 字段，GPS 只是一条带时间、精度和来源的辅助证据，不是已经确认的用户到访地点；需核对它与对应图片时间是否对齐、位置精度是否可靠。
- GPS 位置变化 + 真实视觉场景/活动变化可以增强新 Chapter 边界证据；GPS 轻微漂移、临时失准、室内信号、静止时的坐标跳动不能单独作为拆章依据。
- GPS 可提示区域或供地标候选交叉验证，但不能凭靠近某建筑就断言用户进入、参观、购买或完成某种活动。图片与可靠地点证据冲突时用保守可见描述，避免编造精确地名。
- 画面没有明确地点证据时，不应仅凭 GPS 产生看似肯定的地标名称。输入可包含经过处理的区域提示，但不得假设自己已获得未经提供的地图搜索或地理编码结果。

【强制语言规范：简体中文】
- 所有 Chapter 的 title、story 和 key_moments.text 必须使用简体中文，整天保持同一种语言，不允许某章用英文、某章用中文。
- 地标、艺术品、店铺的准确官方英文专名可以在中文表达中保留，例如“岩石区（The Rocks）”“环形码头（Circular Quay）”“达令港（Darling Harbour）”。
- 专有名词保留原意，不要为了翻译而错误更改地名；正文、标题和瞬间叙述必须是中文句子，不可直接整段输出英文。
- 禁止只因为画面里的招牌是英文就改变输出语言。

【输出只需要编辑决策，程序负责所有引用转换】
仅返回最外层为对象的 JSON：{{"chapters":[{{"title":"...","story":"...","selected_images":[1,3,9],"key_moments":[{{"text":"...","image_index":9}}]}}],"excluded_images":[]}}
必须是对象而不是空数组。不要输出 Markdown、模型内部分析、冗长的 frame_id/asset_id/UUID、证据全集、hero_frame_id、start_clip、end_clip、editorial_summary、schema_version。
整个输出只使用一种编号：真实 IMAGE_INDEX_1_BASED（1 到 {image_count}）。不要输出 CLIP_SEQUENCE 作为图片编号，不要输出时间范围编号。
每章 selected_images 是精心挑选的图库（包括封面），最多10张，通常3–8张，内容很少时可更少。先理解连续完整经历，挑最能代表整个Chapter的封面；其他图片应分别记录环境、重要对象与活动、独特细节及变化，不重复普通步道和相似街景，不混入别章的真实事件。
整天全部图库必须明显少于原始抽帧：优先保留信息量高、有代表性、能够互相补充的照片，不要把每次抽帧都发布成图库。对同一景物、同一视角和重复步行背景，只选最好的一张或少数有明显变化的图片。
优先保留短暂但独特的活动、互动、建筑细节、动物和现场变化。selected_images 第一个数字就是封面，后续按重要性排序；同一 10 秒片段多张仅在不同关键场景时选。跨章节不可复用同一图片。
key_moments 也只引用 IMAGE_INDEX_1_BASED；章节按照真实发生的时间从早到晚输出。程序会根据所有入选图片的实际来源自动计算该章时间跨度，你无需手工填写时间边界。
保持标题、图片和故事对应，不要因为同一地标重复出现就跨时间合并不相干经历。
不确定时输出保守的、证据明确的章节，不得凭空猜想不存在的图片序号。"""
    if retry:
        basic += "\n上一次返回不符合结构或真实索引约束。本次必须给出非空 JSON 对象，且只用 1-based 输入图片索引；不要重新解释这些规则。"
    return basic


def image_labels(evidence: Sequence[tuple[Mapping[str, Any], Mapping[str, Any], Path]],
                 chronology: Mapping[str, str]) -> dict[str, str]:
    result: dict[str, str] = {}
    for idx, (_, frame, _) in enumerate(evidence, 1):
        fid = str(frame["frame_id"])
        label = chronology[fid]
        if not label.startswith("CLIP_SEQUENCE_1_BASED="):
            raise ValueError("Chronology missing clip sequence for image")
        result[fid] = f"IMAGE_INDEX_1_BASED={idx} " + label
    return result


def _index(value: Any, bound: int) -> int | None:
    # Allow only lossless decimal-string -> integer repair; never guess a frame.
    if type(value) is int:
        result = value
    elif isinstance(value, str) and value.isascii() and value.isdecimal():
        result = int(value)
    else:
        return None
    return result if 1 <= result <= bound else None


def _text(value: Any, maximum: int) -> str | None:
    if not isinstance(value, str):
        return None
    value = value.strip()
    return value if 1 <= len(value) <= maximum else None


def convert(raw: object,
            evidence: Sequence[tuple[Mapping[str, Any], Mapping[str, Any], Path]],
            *, max_gallery: int = MAX_GALLERY) -> tuple[dict | None, list[str], list[str]]:
    """Convert model editorial choices to source-bound legacy internal proposal.

    All chapter time spans are inferred from the selected true image indices,
    never guessed from an incompatible second "clip index" numbering system.
    Model-selected stories, order and real gallery images are preserved.
    """
    repairs: list[str] = []
    errors: list[str] = []
    if not isinstance(raw, dict):
        return None, ["top_level_not_object"], repairs
    rows = raw.get("chapters")
    if not isinstance(rows, list) or not 1 <= len(rows) <= MAX_CHAPTERS:
        return None, ["missing_or_invalid_chapters"], repairs
    n_images = len(evidence)
    if not n_images:
        return None, ["empty_input"], repairs
    source_to_seq: dict[str, int] = {}
    images: dict[int, tuple[str, int]] = {}
    for i, (asset, frame, _) in enumerate(evidence, 1):
        source = str(asset["asset_id"])
        if source not in source_to_seq:
            source_to_seq[source] = len(source_to_seq) + 1
        images[i] = (str(frame["frame_id"]), source_to_seq[source])
    excluded: set[int] = set()
    excluded_raw = raw.get("excluded_images", [])
    if not isinstance(excluded_raw, list):
        return None, ["excluded_images_not_array"], repairs
    for x in excluded_raw:
        idx = _index(x, n_images)
        if idx is None:
            errors.append("unknown_excluded_index")
        else:
            excluded.add(idx)
    chapters: list[dict] = []
    seen_gallery: set[int] = set()
    chapter_start_clips: list[int] = []
    chapter_end_clips: list[int] = []
    for pos, item in enumerate(rows, 1):
        label = f"C{pos:02d}"
        if not isinstance(item, dict):
            errors.append(f"{label}:not_object")
            continue
        title, story = _text(item.get("title"), 80), _text(item.get("story"), 1800)
        if title is None or len(title) < 2:
            errors.append(f"{label}:invalid_title")
        if story is None or len(story) < 12:
            errors.append(f"{label}:invalid_story")
        gallery_raw = item.get("selected_images")
        if not isinstance(gallery_raw, list) or not gallery_raw:
            errors.append(f"{label}:invalid_gallery_length")
            continue
        indices: list[int] = []
        for x in gallery_raw:
            idx = _index(x, n_images)
            if idx is None:
                errors.append(f"{label}:selected_image_outside_input")
                continue
            if idx in indices:
                errors.append(f"{label}:duplicate_gallery_index")
                continue
            if idx in excluded:
                errors.append(f"{label}:excluded_gallery_image")
            if idx in seen_gallery:
                errors.append(f"{label}:gallery_reused_across_chapters")
            indices.append(idx)
        if not indices:
            errors.append(f"{label}:empty_gallery_after_validation")
            continue
        if len(indices) > max_gallery:
            errors.append(f"{label}:gallery_over_limit:{len(indices)}>{max_gallery}")
        seen_gallery.update(indices)
        events_raw = item.get("key_moments", [])
        if not isinstance(events_raw, list):
            errors.append(f"{label}:key_moments_not_array")
            continue
        if len(events_raw)>10:
            errors.append(f"{label}:too_many_key_moments")
        moments: list[tuple[str, int]] = []
        for event in events_raw:
            if not isinstance(event, dict):
                errors.append(f"{label}:unstructured_key_moment")
                continue
            text = _text(event.get("text"), 300)
            idx = _index(event.get("image_index"), n_images)
            if text is None or len(text) < 4 or idx is None or idx in excluded:
                errors.append(f"{label}:invalid_key_moment")
                continue
            moments.append((text, idx))
        all_selected = indices + [i for _, i in moments]
        scope_start = min(images[idx][1] for idx in all_selected)
        scope_end = max(images[idx][1] for idx in all_selected)
        chapter_start_clips.append(scope_start)
        chapter_end_clips.append(scope_end)
        # Ignore old redundant model-supplied clip bounds, even on archived
        # V02 responses. Actual selected JPEG provenance defines the span.
        if "start_clip" in item or "end_clip" in item:
            errors.append(f"{label}:unexpected_model_clip_bounds")
        if not moments:
            errors.append(f"{label}:no_key_moment")
        # Explicitly selected evidence only: never expand into unselected clips.
        scoped = list(dict.fromkeys(images[idx][0] for idx in all_selected))
        if not scoped:
            errors.append(f"{label}:empty_derived_clip_span")
            continue
        chapters.append({
            "id": label, "title": title or "", "story": story or "",
            "hero_frame_id": images[indices[0]][0],
            "gallery_frame_ids": [images[idx][0] for idx in indices],
            "experience_frame_ids": scoped,
            "key_moments": [
                {"description": text, "frame_ids": [images[idx][0]]}
                for text,idx in moments
            ],
            "editorial_summary": (
                f"按所选真实图片来源推导片段序号范围：{scope_start}至{scope_end}；"
                "模型独立决定主题、故事与图库。"
            ),
        })
    for j in range(1,len(chapters)):
        if chapter_start_clips[j] <= chapter_end_clips[j-1]:
            errors.append(f"C{j+1}:gallery_source_clip_overlap")
    if errors or not chapters:
        return None, sorted(set(errors or ["no_valid_chapters"])), repairs
    # Source clip chronology is authoritative. Sorting changes only display
    # order and deterministic IDs, never model stories or selected images.
    indexed = list(zip(chapter_start_clips, range(len(chapters)), chapters))
    if [original_i for _, original_i, _ in indexed] != list(range(len(chapters))):
        return None, ["chapters_out_of_source_order"], repairs
    chapters = [item for _, _, item in indexed]
    for i, chapter in enumerate(chapters, 1):
        chapter["id"] = f"C{i:02d}"

    # Content-based curation is the model's task; never round-robin cut.
    selected_total = sum(len(ch["gallery_frame_ids"]) for ch in chapters)
    if n_images>=60 and selected_total >= math.ceil(n_images*.75):
        return None, ["whole_day_gallery_not_curated"], repairs
    heading = "、".join(ch["title"] for ch in chapters)
    summary = "当天按时间顺序记录了：" + heading
    rationale = f"模型依据原始图片的时间线和场景变化组织了{len(chapters)}个章节；章节时间范围来自真实所选图片。"
    result = {
        "schema_version": "DIRECT_VLM_ALL_FRAMES_V01",
        "day_summary": summary[:1600],
        "chapter_count_rationale": rationale,
        "excluded_non_lived_frame_ids": [images[idx][0] for idx in sorted(excluded)],
        "chapters": chapters,
    }
    return result, [], repairs
