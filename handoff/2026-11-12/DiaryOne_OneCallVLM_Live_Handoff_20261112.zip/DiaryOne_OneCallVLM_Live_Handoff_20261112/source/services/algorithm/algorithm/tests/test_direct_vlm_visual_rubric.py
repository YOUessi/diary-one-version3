"""Global VLM editorial rubric: generalizable; no verbose per-photo output contract."""
from diary_one_ci import direct_vlm_compact as compact


def test_visual_editorial_rubric_evaluates_images_not_timestamps():
    prompt = compact.prompt(image_count=230, clip_count=160)
    assert "按视觉内容和信息增量去重" in prompt
    assert "时间相近直接删除" in prompt
    assert "独特画面即使有轻微瑕疵" in prompt
    assert "建立地点" in prompt
    assert "活动" in prompt
    assert "封面" in prompt
    assert "同一经历" in prompt
    assert "20 张" in prompt


def test_no_route_template_or_selection_id_is_assumed_in_production_prompt():
    prompt = compact.prompt(image_count=230, clip_count=160)
    for manually_curated_image_id in ("124532", "124627", "124524", "124534"):
        assert manually_curated_image_id not in prompt
    assert "不要预设悉尼或任何其他路线" in prompt
    assert "没有进入图库的图片依然是有效视觉证据" in prompt


def test_optional_gps_is_not_claimed_as_existing_visual_truth():
    prompt = compact.prompt(image_count=232, clip_count=161)
    assert "默认可能完全没有 GPS" in prompt
    assert "GPS 只是一条带时间、精度和来源的辅助证据" in prompt
    assert "GPS 位置变化 + 真实视觉场景/活动变化" in prompt
    assert "不能凭靠近某建筑就断言用户进入" in prompt
    assert "不得假设自己已获得未经提供的地图搜索" in prompt


def test_editorial_rubric_does_not_expand_the_json_contract():
    output_properties = compact.SCHEMA["properties"]
    assert "chapters" in output_properties
    chapter = output_properties["chapters"]["items"]
    assert set(chapter["required"]) == {"title", "story", "selected_images"}
    assert set(chapter["properties"]) == {
        "title", "story", "selected_images", "key_moments"
    }
    assert "gps" not in output_properties
    assert "image_decisions" not in output_properties
    assert "all_image_reasons" not in output_properties
    assert compact.MAX_GALLERY == 20


def test_rewrite_stays_simplified_chinese_and_uses_image_indices_only():
    p = compact.prompt(image_count=12, clip_count=6, retry=True)
    assert "所有 Chapter 的 title、story 和 key_moments.text 必须使用简体中文" in p
    assert "IMAGE_INDEX_1_BASED" in p
    assert "不要输出 CLIP_SEQUENCE 作为图片编号" in p
    assert "上一次返回" in p
