const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const ts = require('typescript');

const root = path.resolve(__dirname, '..');
const jsx = (type, props) => ({ type, props: props || {} });
function loadTs(relative, dependencies) {
  const filename = path.join(root, relative);
  const compiled = ts.transpileModule(fs.readFileSync(filename,'utf8'), {
    compilerOptions: {module:ts.ModuleKind.CommonJS, target:ts.ScriptTarget.ES2022,
      jsx:ts.JsxEmit.ReactJSX, esModuleInterop:true}
  }).outputText;
  const module = {exports:{}};
  vm.runInNewContext(compiled,{
    module,exports:module.exports,console,
    require(name) {
      if (name === 'react/jsx-runtime') return {jsx,jsxs:jsx};
      if (Object.hasOwn(dependencies,name)) return dependencies[name];
      throw Error('Unexpected dependency '+name);
    }
  },{filename});
  return module.exports;
}
function descendants(tree) {
  if (!tree || typeof tree !== 'object') return [];
  return [tree,...[tree.props?.children].flat(Infinity).flatMap(descendants)];
}
const theme = {colors:{}, layout:{heroHome:198}, radius:{media:8},
  type:{metadata:{}},spacing:{}};
const labels = {playVideo:'播放视频',closeVideo:'关闭视频',showImage:'查看图片'};

function momentComponent() {
  const motion = () => null;
  const compiled = loadTs('src/components/MomentMedia.tsx',{
    react:{},
    'react-native':{Image:'Image',Pressable:'Pressable',Text:'Text',
      View:'View',StyleSheet:{create:x=>x}},
    '../theme':theme,
    '../store/useAppStore':{useAppStore:selector=>selector({language:'zh-Hans'})},
    '../domain/strings':{appStrings:()=>labels},
    './MomentPlayer':{MomentPlayer:()=>null},
    './ChapterMotionPlayer':{ChapterMotionPlayer:motion}
  });
  return {MomentMedia:compiled.MomentMedia,motion};
}
function motionCover(seed) {
  return {kind:'chapter_motion',status:'source_window',
    posterUri:'file:///poster'+seed+'.jpg',motionUri:'file:///original'+seed+'.mov',
    sourceVideoUri:'file:///original'+seed+'.mov',focusTimeSec:5,
    clipStartSec:3.5,clipEndSec:6.5,applePhotosPaired:false};
}

test('20 motion cards are idle posters, not 20 concurrent players',()=>{
  const {MomentMedia,motion} = momentComponent();
  let taps=0,stop=0;
  const props=i=>({uri:'file:///poster'+i+'.jpg',playbackUri:'file:///original'+i+'.mov',
    motionCover:motionCover(i),playing:false,onPlay:()=>{taps++;},onStop:()=>{stop++;}});
  const idle=Array.from({length:20},(_,i)=>MomentMedia(props(i)));
  assert.equal(idle.filter(x=>descendants(x).some(y=>y.type===motion)).length,0);
  assert.equal(idle.filter(x=>x.type==='Pressable').length,20);
  idle[9].props.onPress();assert.equal(taps,1);
  assert.equal(stop,0);
  const active=MomentMedia({...props(9),playing:true});
  assert.equal(descendants(active).filter(x=>x.type===motion).length,1);
  const stopButton=descendants(active).find(x=>x.type==='Pressable'&&x.props.accessibilityLabel==='关闭视频');
  assert.ok(stopButton);
  stopButton.props.onPress();assert.equal(stop,1);
});

test('20 selected images: at most 3 native MOV exports, all keep 3s window',async()=>{
  const calls=[];
  const module=loadTs('src/pipeline/buildLiveChapterCovers.ts',{
    'expo-file-system/legacy':{
      makeDirectoryAsync:async()=>{},
      getInfoAsync:async()=>({exists:true,isDirectory:false}),
    },
    'expo-crypto':{
      CryptoDigestAlgorithm:{SHA256:'SHA256'},
      digestStringAsync:async(_algorithm,value)=>value.replace(/[^a-z0-9]/gi,'').slice(0,60),
    },
    expo:{
      requireOptionalNativeModule:()=>({
        exportChapterMotion:async(video,dest,key,focusMs,durationMs)=>{
          calls.push([video,dest,key,focusMs,durationMs]);
          return {videoUri:'file:///rendered/'+calls.length+'.mov',
            stillUri:'file:///rendered/'+calls.length+'.jpg',
            startMs:focusMs-1500,endMs:focusMs+1500,
            focusMs,clipDurationMs:durationMs,isApplePhotosPaired:false};
        }
      }),
    },
  });
  assert.equal(module.MAX_EAGER_NATIVE_MOTION_EXPORTS_PER_CHAPTER,3);
  const moments=Array.from({length:20},(_,i)=>({
    id:'media-'+i,posterUri:'file:///poster-'+i+'.jpg',
    playbackUri:'file:///source-'+i+'.mov',sourceAssetId:'asset-'+i,
    selectedFrameId:'frame-'+i,focusTimeSec:5,sourceDurationSec:10,
  }));
  const chapters=await module.buildLiveChapterCovers(
    [{id:'c1',title:'章',heroUri:moments[0].posterUri,moments}], 'file:///bundle/');
  assert.equal(chapters.length,1);
  assert.equal(chapters[0].moments.length,20);
  assert.equal(calls.length,3);
  assert.equal(chapters[0].moments.filter(m=>m.motionCover.status==='rendered').length,3);
  assert.equal(chapters[0].moments.filter(m=>m.motionCover.status==='source_window').length,17);
  assert.ok(chapters[0].moments.every(m=>m.motionCover.applePhotosPaired===false));
  assert.ok(chapters[0].moments.slice(3).every(m=>m.motionCover.clipEndSec-m.motionCover.clipStartSec===3));
  assert.equal(chapters[0].motionCover.status,'rendered');
});
