# V03+ BFF API与Schema合同

1. 手机用已认证multipart POST /v1/day-revisions，携带day_revision_id、Bundle manifest及全部已选JPEG；BFF检查文件SHA256、来源asset_id、frame_id、PTS和用户会话。返回job_id。
2. 手机GET /v1/jobs/{job_id}轮询（ID幂等，丢包不能新建重复收费任务）。
3. 云端Qwen3.8-Flash一次收到全部JPEG及IMAGE_INDEX_1_BASED、CLIP_SEQUENCE_1_BASED和可信来源视频相对时间。JSON对象包含chapters（title、story、selected_images、key_moments）及excluded_images。selected_images第一张为封面，最多8张。输入编号与源Clip编号不同。
4. 云端根据上传Manifest将真实JPEG Index确定性映射到frame_id/asset_id，BFF输出DIARY_ONE_DIRECT_VLM_CHAPTER_V01、chapters[*].selected_media、hero_frame_id、source_asset_id、focus_pts_ms、bundle_manifest_sha256/session_id和trace；不得凭序号猜补帧。
5. 端侧校验结果，映射回仍在手机上的原始10秒视频，生成对齐3秒静音MOV/JPG供App内自动播放。不是已配对Apple Photos原生Live Photo。
6. 候选研究开关：DIARY_ONE_X02_EDITOR=direct_vlm_v03plus。生产发布开关DIARY_ONE_ALLOW_V03PLUS_PUBLISH默认关闭；打开也只是允许符合机械合同的结果，并非保证图文语义正确。
7. 服务端Qwen Key仅在后端，不得打入App。原图只通过受认证的BFF可见，不能把base64/用户图、密钥或原始故事提交公共GitHub。

返回合同的当前SHA256：9b0402bd07ca25fe93aaf17ea1260f82947730661d71ad75b89e25425cf8532c
