# 验收与限制

- Python：python3 tests/handoff_smoke.py（需要jsonschema等基础环境）；它验证V03原始Prompt、V03+精选4条、max8、来源/拒绝规则和跨BFF/手机SHA合同。
- Python源码语法检查：python3 -m compileall -q source/services/algorithm/algorithm/src/diary_one_ci source/services/bff。
- 在source/apps/mobile执行npm ci和npm run typecheck；iOS原生模型和Motion需安装正式Dev Client/TestFlight，Expo Go不足。
- 新版研究源仓库完整回归：259 passed，7 skipped（V03+、旧V03、旧V02、BFF）；新8图合同与完整Mac手机版本的联调需继续做真机回归。
- 新版真实Qwen实验：18次请求，估算费用¥2.2461。最简Prompt8次中4次通过结构/来源检查；尚未通过语义污染生产门禁。
- 版本结构：原始Mac phone Live源码（含当时尚未提交的V05修改）＋冻结V03 Python backend＋新增V03+ opt-in。该组合是供后端联调的工程交付，**不是声称已经端到端部署/上线**。
- 来源权重image_encoder.onnx和prompts.f32.bin明确缺失，需团队受控分发。授权/商业许可仍需开发团队独立确认。
