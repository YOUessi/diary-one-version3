# 手机与后端代码链路（V03+）

第一人称10s片段 -> 手机真实PTS解码 -> MobileCLIP-S0 FP16 + endpointV05 + coverageV07挑选1–5张(特例更多) -> JPEG768×1024/SHA256 + Bundle V04/V05 -> 生产BFF的认证day_revision异步Job -> 一次Qwen3.8-Flash全图编辑 -> Chapter/Story/封面/Gallery -> BFF和手机再核验真实Frame与视频来源 -> 手机本地原10秒MP4生成3秒JPG+静音MOV -> App内动态封面。

手机入口：
- source/apps/mobile/src/evidence/runSemanticVideoEvidence.ts：端侧分窗、FP16语义选帧。
- source/apps/mobile/src/evidence/mobileclip/analyzer.ts、endpointV05.ts、coverageV07.ts：模型和门控。
- source/apps/mobile/modules/diary-one-vision/ios/：Swift AVFoundation抽帧/三秒Motion，Expo Go不执行本地原生能力。
- source/apps/mobile/src/pipeline/buildAppLibraryBundle.ts：Bundle和哈希。
- source/apps/mobile/src/backend/productionCloudService.ts：正式BFF上传、Job轮询。
- source/apps/mobile/src/cloud/validateDirectVlmResult.ts：结果Frame绑定和max8再验证。
- source/apps/mobile/src/pipeline/attachChapterMedia.ts + buildLiveChapterCovers.ts：只为最终入选Chapter准备静音MOV/JPG。

后端：
- source/services/algorithm/algorithm/src/diary_one_ci/direct_vlm_compact.py：V03原Prompt/Schema，不做本次新修改。
- source/services/algorithm/algorithm/src/diary_one_ci/direct_vlm_v03plus.py：V03+最简四条精选补充/来源门禁。
- source/services/algorithm/algorithm/src/diary_one_ci/x01_server.py：研究路由，DIARY_ONE_X02_EDITOR=direct_vlm_v03plus选择候选，默认direct_vlm。
- source/services/algorithm/algorithm/src/diary_one_ci/x02.py：Qwen网关。
- source/services/bff/shared/direct_result_contract.py：真实manifest/JPEG绑定/max8。
- source/services/bff/shared/contracts/direct_vlm_chapter_v01.schema.json：结果合同，最大8图。
- source/services/bff/shared/result_admit.py：候选默认不能发表到App。
- source/services/bff/bff/routes/day_revisions.py、jobs.py：生产认证上传/异步结果。

**责任边界**：云端不会生成/返回Apple Photos系统Live Photo，只有绑定真实封面图的Frame/原视频来源和PTS；手机用本地原始视频生成3秒Motion。原MP4不上传给VLM。手机完整原生构建须有授权FP16 ONNX权重；本包仅含Manifest。

**限制**：一日最多250张模型输入JPEG、35MiB原JPEG字节保护，不允许静默截掉时间尾部；Qwen单次调用、结构失败最多重复一次完整同内容调用，产生额外Token费用。真实Story、封面、地名与作品准确性仍需独立质量验收。
